

public class Oppgave2_3 {

  public static void main (String[] args) {
    Planet mars = new Planet("Mars", 3389.5, 3.711);
    Planet pluto = new Planet("Pluto", 1188.3 , 0.658);

    mars.printInfoPlanet(); // Printer ut info om mars
    pluto.printInfoPlanet(); // Printer ut info om pluto
  }

}
