


public class main {

  public static void main (String[] args){
    Student nikolatesla = new Student();

    nikolatesla.fornavn = "Nikola";
    nikolatesla.etternavn ="Tesla";
    nikolatesla.alder =59;
    nikolatesla.studentId =165135468;

    nikolatesla.printStudentinformasjon();


  }

}
