
public class Student{

public String fornavn;
public String etternavn;
public int alder;
public int studentId;

public void printStudentinformasjon() {
  System.out.println(fornavn + " " + etternavn + " " + alder + " år" + " " + "StudentID : " + studentId  );
}

// Student student = new Student();
//
// student.fornavn = "Linus";
// student.etternavn = "Torvalda";
// student.studentId = "0092653";





}
